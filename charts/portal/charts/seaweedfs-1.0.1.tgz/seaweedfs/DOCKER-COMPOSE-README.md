# SeaweedFS Docker Compose Deployment

This directory contains a Docker Compose configuration for running a standalone SeaweedFS instance with Master, Volume, Filer, and S3 Gateway components.

## Quick Start

### 1. Prerequisites

- Docker and Docker Compose installed on your system
- At least 2GB of available RAM
- Sufficient disk space for data storage

### 2. Configuration

Copy the example environment file and configure your credentials:

```bash
cp env.example .env
```

Edit the `.env` file and update the following **required** variables:

```bash
SEAWEEDFS_ADMIN_ACCESS_KEY_ID=your_seaweedfs_admin_access_key
SEAWEEDFS_ADMIN_SECRET_ACCESS_KEY=your_seaweedfs_admin_secret_key
```

**Important:** Replace `your_seaweedfs_admin_access_key` and `your_seaweedfs_admin_secret_key` with your own secure credentials. These will be used to authenticate with the S3 API.

### 3. Start SeaweedFS

```bash
docker-compose up -d
```

### 4. Verify Deployment

Check the status of the container:

```bash
docker-compose ps
```

Check the logs:

```bash
docker-compose logs -f seaweedfs
```

Access the Master UI:

```
http://localhost:9333
```

## Architecture

The deployment includes all SeaweedFS components in a single container:

- **Master Server**: Manages volume servers and metadata (ports 9333, 19333)
- **Volume Server**: Stores actual file data (ports 8080, 18080)
- **Filer**: Provides file system interface (ports 8888, 18888)
- **S3 Gateway**: S3-compatible API (port 8333)

## Service Ports

| Service | Port | Protocol | Environment Variable |
|---------|------|----------|----------------------|
| Master HTTP | 9333 | HTTP | SEAWEEDFS_MASTER_PORT |
| Master gRPC | 19333 | gRPC | SEAWEEDFS_MASTER_GRPC_PORT |
| Volume HTTP | 8080 | HTTP | SEAWEEDFS_VOLUME_PORT |
| Volume gRPC | 18080 | gRPC | SEAWEEDFS_VOLUME_GRPC_PORT |
| Filer HTTP | 8888 | HTTP | SEAWEEDFS_FILER_PORT |
| Filer gRPC | 18888 | gRPC | SEAWEEDFS_FILER_GRPC_PORT |
| S3 Gateway | 8333 | HTTP | SEAWEEDFS_S3_PORT |
| Metrics | 9324 | HTTP | SEAWEEDFS_METRICS_PORT |

## Configuration Options

All configuration options are managed through environment variables in the `.env` file:

### Image Configuration

- `SEAWEEDFS_IMAGE`: Docker image to use (default: `caapim/seaweedfs:5.3.3`)

### Authentication (Required)

- `SEAWEEDFS_ADMIN_ACCESS_KEY_ID`: S3 admin access key
- `SEAWEEDFS_ADMIN_SECRET_ACCESS_KEY`: S3 admin secret key

### Performance Tuning

- `SEAWEEDFS_LOGGING_LEVEL`: Logging verbosity (0=debug, 1=info, 2=warn, 3=error, 4=fatal)
- `SEAWEEDFS_IDLE_TIMEOUT`: Connection idle timeout in seconds (default: 30)
- `SEAWEEDFS_MIN_FREE_SPACE_PERCENT`: Minimum free space percentage (default: 7)
- `SEAWEEDFS_COMPACTION_MBPS`: Compaction speed limit in MB/s (default: 50)
- `SEAWEEDFS_FILER_DIR_LIST_LIMIT`: Max directory listing entries (default: 100000)
- `SEAWEEDFS_MASTER_VOLUME_SIZE_LIMIT_MB`: Maximum volume size in MB (default: 1024)

## Using the S3 API

Once SeaweedFS is running, you can access it using any S3-compatible client:

### AWS CLI Example

Configure AWS CLI:

```bash
aws configure set aws_access_key_id <your_access_key>
aws configure set aws_secret_access_key <your_secret_key>
```

Create a bucket:

```bash
aws --endpoint-url=http://localhost:8333 s3 mb s3://mybucket
```

Upload a file:

```bash
aws --endpoint-url=http://localhost:8333 s3 cp myfile.txt s3://mybucket/
```

List files:

```bash
aws --endpoint-url=http://localhost:8333 s3 ls s3://mybucket/
```

### Python boto3 Example

```python
import boto3

s3 = boto3.client(
    's3',
    endpoint_url='http://localhost:8333',
    aws_access_key_id='your_access_key',
    aws_secret_access_key='your_secret_key'
)

# Create bucket
s3.create_bucket(Bucket='mybucket')

# Upload file
s3.upload_file('myfile.txt', 'mybucket', 'myfile.txt')

# List objects
response = s3.list_objects_v2(Bucket='mybucket')
for obj in response.get('Contents', []):
    print(obj['Key'])
```

## Data Persistence

Data is persisted in a Docker volume named `seaweedfs-data`. This volume is automatically created and will persist even if the container is removed.

To backup your data:

```bash
docker run --rm -v seaweedfs-data:/data -v $(pwd):/backup alpine tar czf /backup/seaweedfs-backup.tar.gz /data
```

To restore from backup:

```bash
docker run --rm -v seaweedfs-data:/data -v $(pwd):/backup alpine tar xzf /backup/seaweedfs-backup.tar.gz -C /
```

## Management Commands

### Start services

```bash
docker-compose up -d
```

### Stop services

```bash
docker-compose stop
```

### Stop and remove containers

```bash
docker-compose down
```

### View logs

```bash
docker-compose logs -f seaweedfs
```

### Restart services

```bash
docker-compose restart
```

### Scale (not recommended for standalone deployment)

```bash
docker-compose up -d --scale seaweedfs=1
```

## Health Checks

The SeaweedFS container includes a health check that monitors the cluster status endpoint. You can check the health status with:

```bash
docker inspect --format='{{json .State.Health}}' seaweedfs | jq
```

## Troubleshooting

### Container fails to start

Check the logs:

```bash
docker-compose logs seaweedfs
```

Common issues:
- Ports already in use: Change port mappings in `.env` file
- Missing credentials: Ensure `SEAWEEDFS_ADMIN_ACCESS_KEY_ID` and `SEAWEEDFS_ADMIN_SECRET_ACCESS_KEY` are set

### Cannot connect to S3 API

1. Verify the container is running:
   ```bash
   docker-compose ps
   ```

2. Check if S3 port is accessible:
   ```bash
   curl http://localhost:8333
   ```

3. Verify credentials are correct in `.env` file

### Low disk space warnings

Adjust the `SEAWEEDFS_MIN_FREE_SPACE_PERCENT` variable in `.env` file to a lower value.

### Performance issues

Consider tuning these parameters in `.env`:
- Increase `SEAWEEDFS_COMPACTION_MBPS` for faster compaction
- Increase `SEAWEEDFS_MASTER_VOLUME_SIZE_LIMIT_MB` for larger volumes
- Decrease `SEAWEEDFS_FILER_DIR_LIST_LIMIT` if directory listings are slow

## Differences from Kubernetes Deployment

This Docker Compose deployment differs from the Kubernetes deployment in the following ways:

1. **Single Container**: All components (Master, Volume, Filer, S3) run in a single container instead of separate pods
2. **No MySQL**: Database persistence is handled by SeaweedFS's internal LevelDB (configurable in filer.toml)
3. **No Minio**: External object storage not required in standalone mode
4. **Simplified Networking**: Uses Docker bridge networking instead of Kubernetes services
5. **No Replication**: Configured for single-node deployment (replication: 000)
6. **Local Volume**: Uses Docker volume instead of PersistentVolumeClaims

## Advanced Configuration

For advanced configuration options, you can modify the `docker-compose.yaml` file directly:

### Custom Master/Filer Configuration

If you need to provide custom `master.toml` or `filer.toml` files, you can mount them as volumes:

```yaml
volumes:
  - ./master.toml:/etc/seaweedfs/master.toml:ro
  - ./filer.toml:/etc/seaweedfs/filer.toml:ro
  - seaweedfs-data:/opt/data
```

### Enable TLS/SSL

Add certificate volumes and update the command to include TLS options:

```yaml
volumes:
  - ./certs:/certs:ro
  - seaweedfs-data:/opt/data
```

Update the command with SSL flags:
```bash
-s3.cert.file=/certs/tls.crt \
-s3.key.file=/certs/tls.key \
```

## Security Considerations

1. **Credentials**: Always use strong, unique credentials for `SEAWEEDFS_ADMIN_ACCESS_KEY_ID` and `SEAWEEDFS_ADMIN_SECRET_ACCESS_KEY`
2. **Network Exposure**: In production, consider using a reverse proxy (nginx, traefik) instead of directly exposing ports
3. **TLS**: Enable TLS for S3 API in production environments
4. **Firewall**: Restrict access to SeaweedFS ports using firewall rules
5. **Regular Backups**: Implement regular backup strategies for your data

## Support and Documentation

- **SeaweedFS Documentation**: https://github.com/seaweedfs/seaweedfs/wiki
- **S3 API Documentation**: https://github.com/seaweedfs/seaweedfs/wiki/Amazon-S3-API
- **Docker Compose Documentation**: https://docs.docker.com/compose/

## License

This Docker Compose configuration follows the same license as the SeaweedFS project and the APIM charts.





