# Kafka External Access Troubleshooting Guide

## Common Issue: "Error connecting to node kafka-X-external:9094"

### Symptom
External clients (like API Gateway) receive an error when trying to connect to Kafka:
```
Error connecting to node kafka-3-external:9094
```

Even though you're providing the correct LoadBalancer IPs in the bootstrap servers configuration.

### Root Cause
This error occurs when Kafka's **advertised listeners** are configured with service hostnames instead of LoadBalancer IP addresses. When clients connect to Kafka, they receive metadata that tells them how to reach each broker. If this metadata contains unresolvable hostnames (like `kafka-3-external:9094`), external clients cannot connect.

### Why This Happens
The Kafka pods use an init container to discover LoadBalancer IPs at startup. If this discovery fails, the pods may start with incorrect advertised listeners. Common reasons for discovery failure:

1. **Timing Issues**: LoadBalancer IPs not assigned when pods start
2. **RBAC Permissions**: ServiceAccount lacks permissions to query services
3. **API Server Issues**: Temporary connectivity or performance issues
4. **Cloud Provider Delays**: LoadBalancer provisioning takes longer than expected

## Permanent Solutions

### Solution 1: Fail-Fast Configuration (Recommended)

The chart now includes a **fail-fast mechanism** that prevents Kafka pods from starting with incorrect configuration.

**How it works:**
- If LoadBalancer IP discovery fails, the init container exits with an error
- Kubernetes automatically retries the pod startup
- The pod only starts when LoadBalancer IPs are successfully discovered

**Configuration:**
```yaml
kafka:
  externalAccess:
    discovery:
      # Pod will fail if LoadBalancer IP cannot be discovered
      failOnDiscoveryFailure: true  # Default: true
      # Maximum time to wait for LoadBalancer IP
      timeoutSeconds: 120  # Default: 120 seconds
      # Retry interval
      retryIntervalSeconds: 5  # Default: 5 seconds
```

**Benefits:**
- ✅ Prevents incorrect advertised listeners
- ✅ No manual intervention required
- ✅ Kubernetes handles retries automatically
- ✅ Clear error messages in pod logs

### Solution 2: Increase Timeout

If your cloud provider takes longer to provision LoadBalancers, increase the timeout:

```yaml
kafka:
  externalAccess:
    discovery:
      timeoutSeconds: 300  # Wait up to 5 minutes
      retryIntervalSeconds: 10  # Check every 10 seconds
```

### Solution 3: Pre-provision LoadBalancer IPs

Use static LoadBalancer IPs to avoid provisioning delays:

```yaml
kafka:
  externalAccess:
    loadBalancerIPs:
      - "10.252.148.48"
      - "10.252.148.117"
      - "10.252.148.244"
```

## Immediate Fix (When Issue Occurs)

If Kafka pods are already running with incorrect advertised listeners:

### Step 1: Verify the Issue
```bash
# Check current advertised listeners
kubectl exec -n <namespace> kafka-1 -- cat /shared/node-id.env

# Look for hostnames instead of IPs:
# BAD:  EXTERNAL://kafka-1-external:9094
# GOOD: EXTERNAL://10.252.148.48:9094
```

### Step 2: Restart Kafka Pods
```bash
# Delete all Kafka pods (StatefulSet will recreate them)
kubectl delete pod kafka-1 kafka-2 kafka-3 -n <namespace>

# Wait for pods to restart
kubectl get pods -n <namespace> -w
```

### Step 3: Verify Fix
```bash
# Check init container logs
kubectl logs -n <namespace> kafka-1 -c kafka-init | grep "Discovered LoadBalancer IP"

# Should show:
# ✓ Successfully discovered LoadBalancer address: 10.252.148.48

# Verify advertised listeners
kubectl exec -n <namespace> kafka-1 -- cat /shared/node-id.env

# Should show:
# KAFKA_CFG_ADVERTISED_LISTENERS=INTERNAL://kafka-1.kafka:9092,CONTROLLER://kafka-1.kafka:9093,EXTERNAL://10.252.148.48:9094
```

## Diagnostic Commands

### Check LoadBalancer Services
```bash
# List all Kafka external services
kubectl get svc -n <namespace> | grep kafka-.*-external

# Check specific service details
kubectl describe svc kafka-1-external -n <namespace>

# Get LoadBalancer IP
kubectl get svc kafka-1-external -n <namespace> -o jsonpath='{.status.loadBalancer.ingress[0].ip}'
```

### Check RBAC Permissions
```bash
# Verify ServiceAccount has permissions
kubectl auth can-i get services \
  --as=system:serviceaccount:<namespace>:kafka \
  -n <namespace>

# Check Role permissions
kubectl get role kafka -n <namespace> -o yaml
```

### Check Init Container Logs
```bash
# View init container logs (for running pods)
kubectl logs -n <namespace> kafka-1 -c kafka-init

# View logs for failed pods
kubectl logs -n <namespace> kafka-1 -c kafka-init --previous
```

### Check Advertised Listeners
```bash
# Check all brokers
for i in 1 2 3; do
  echo "=== kafka-$i ==="
  kubectl exec -n <namespace> kafka-$i -- cat /shared/node-id.env | grep ADVERTISED
done
```

## Prevention Best Practices

1. **Enable Fail-Fast**: Always use `failOnDiscoveryFailure: true` (default)
2. **Monitor Init Containers**: Set up alerts for init container failures
3. **Adequate Timeout**: Set timeout based on your cloud provider's typical provisioning time
4. **RBAC Verification**: Ensure ServiceAccount has required permissions before deployment
5. **Pre-provision Resources**: Use static IPs or pre-create LoadBalancer services when possible

## Configuration Reference

### Full Configuration Example
```yaml
kafka:
  # Number of Kafka brokers
  replicaCount: 3
  
  # Ordinals configuration (for upgrades from Kafka 3.x)
  ordinals:
    start: 1
  
  # ServiceAccount configuration
  serviceAccount:
    create: true
    name: ""
    automountServiceAccountToken: true  # Required for kubectl access
  
  # RBAC configuration
  rbac:
    create: true  # Creates Role with service get/list/watch permissions
  
  # External access configuration
  externalAccess:
    enabled: true
    serviceType: LoadBalancer
    port: 9094
    autoAdvertisedListeners: true
    
    # Discovery configuration (NEW)
    discovery:
      timeoutSeconds: 120
      retryIntervalSeconds: 5
      failOnDiscoveryFailure: true
    
    # Optional: Static LoadBalancer IPs
    loadBalancerIPs: []
    
    # Optional: LoadBalancer annotations
    annotations:
      cloud.google.com/load-balancer-type: Internal
```

## Related Issues

- **Issue**: Pods stuck in `Init:Error` state
  - **Cause**: LoadBalancer IP discovery failing with `failOnDiscoveryFailure: true`
  - **Solution**: Check LoadBalancer provisioning and RBAC permissions

- **Issue**: Pods start but clients can't connect
  - **Cause**: `failOnDiscoveryFailure: false` allowing pods to start with hostnames
  - **Solution**: Enable `failOnDiscoveryFailure: true` and restart pods

- **Issue**: Discovery timeout too short
  - **Cause**: Cloud provider takes longer than 120 seconds to provision LoadBalancers
  - **Solution**: Increase `timeoutSeconds` value

## Support

For additional help:
1. Check pod events: `kubectl describe pod kafka-1 -n <namespace>`
2. Check StatefulSet status: `kubectl describe statefulset kafka -n <namespace>`
3. Review init container logs with full output
4. Verify cloud provider LoadBalancer quota and limits

