package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"os"

	_ "github.com/go-sql-driver/mysql"
)

// Segment - Druid Segment
type Segment struct {
	ID          string          `json:"id"`
	DataSource  string          `json:"dataSource"`
	CreatedDate string          `json:"created_date"`
	Start       string          `json:"start"`
	End         string          `json:"end"`
	Partitioned int             `json:"partitioned"`
	Version     string          `json:"version"`
	Used        int             `json:"used"`
	Payload     json.RawMessage `json:"payload"`
}

// Payload - Segment Payload
type Payload struct {
	DataSource    string    `json:"dataSource"`
	Interval      string    `json:"interval"`
	Version       string    `json:"version"`
	LoadSpec      LoadSpec  `json:"loadSpec"`
	Dimensions    string    `json:"dimensions"`
	Metrics       string    `json:"metrics"`
	ShardSpec     ShardSpec `json:"shardSpec"`
	BinaryVersion int       `json:"binaryVersion"`
	Size          int       `json:"size"`
	Identifier    string    `json:"identifier"`
}

// LoadSpec - Payload LoadSpec
type LoadSpec struct {
	Type     string `json:"type"`
	Bucket   string `json:"bucket"`
	Key      string `json:"key"`
	S3Schema string `json:"S3Schema"`
}

// ShardSpec - Payload ShardSpec
type ShardSpec struct {
	Type         string `json:"type"`
	PartitionNum int    `json:"partitionNum"`
	Partitions   int    `json:"partitions"`
}

func main() {
	mysqlUsername := os.Getenv("MYSQL_USERNAME")
	mysqlPassword := os.Getenv("MYSQL_PASSWORD")
	mysqlHost := os.Getenv("MYSQL_HOST")
	mysqlPort := os.Getenv("MYSQL_PORT")
	mysqlDb := os.Getenv("DATABASE_NAME")
	bucketName := os.Getenv("BUCKET_NAME")

	db, err := sql.Open("mysql", mysqlUsername+":"+mysqlPassword+"@tcp("+mysqlHost+":"+mysqlPort+")/"+mysqlDb)
	ErrorCheck(err)

	// close connection when queries are finished.
	defer db.Close()

	PingDB(db)

	// query all data
	rows, err := db.Query("SELECT id, CONVERT(payload using utf8) AS payload FROM druid_segments;")
	ErrorCheck(err)

	var segment = Segment{}

	for rows.Next() {
		err = rows.Scan(&segment.ID, &segment.Payload)
		ErrorCheck(err)
		var payload = Payload{}
		err = json.Unmarshal([]byte(segment.Payload), &payload)
		ErrorCheck(err)
		//Update the Druid Meta store if the bucket name doesn't match
		if payload.LoadSpec.Bucket != bucketName {
			payload.LoadSpec.Bucket = bucketName
			payload, err := json.Marshal(payload)
			ErrorCheck(err)
			query, err := db.Prepare("UPDATE druid_segments SET payload=? WHERE id=?")
			ErrorCheck(err)
			res, err := query.Exec(payload, segment.ID)
			ErrorCheck(err)
			a, err := res.RowsAffected()
			ErrorCheck(err)
			fmt.Println(segment.ID + " updated " + string(a) + " row affected")
		} else {
			fmt.Println("no update required to: " + segment.ID)
		}
	}
}

// ErrorCheck - generic error handler
func ErrorCheck(err error) {
	if err != nil {
		panic(err.Error())
	}
}

// PingDB - check database reachability
func PingDB(db *sql.DB) {
	err := db.Ping()
	ErrorCheck(err)
}
